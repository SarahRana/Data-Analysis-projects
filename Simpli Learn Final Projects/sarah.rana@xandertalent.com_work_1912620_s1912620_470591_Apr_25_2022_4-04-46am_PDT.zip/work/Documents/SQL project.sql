alter table employee.data_science_team add primary key(EMP_ID(10));

/*3. Query to fetch emp_id, first_name, last_name, gender, and department from 
employee record table, and make a list of employees and details of their department*/
select EMP_ID,FIRST_NAME,LAST_NAME,GENDER,DEPT from employee.emp_record_table;

/*4. Query to fetch emp_id, first_name, last_name, gender, dept and emp_rating if
the emp_rating is less than 2, greater than 4, and between 2-4 */
select EMP_ID,FIRST_NAME,LAST_NAME,GENDER,DEPT,EMP_RATING from employee.emp_record_table
where EMP_RATING < 2;
select EMP_ID,FIRST_NAME,LAST_NAME,GENDER,DEPT,EMP_RATING from employee.emp_record_table
where EMP_RATING > 4;
select EMP_ID,FIRST_NAME,LAST_NAME,GENDER,DEPT,EMP_RATING from employee.emp_record_table
where EMP_RATING between 2 and 4;

/*5. Query to concatenate the first_name and last_name of employees in the finance department 
from employee table- give resultant column alias as name*/
select concat(first_name,' ',last_name) as Name, DEPT from employee.emp_record_table
where dept = 'FINANCE';

/*6. Query to list only those employees who have someone reporting to them. Also, show the 
number of reporters(including the president)*/
select coalesce(MANAGER_ID,'President'), count(*) as no_of_reporters from employee.emp_record_table
group by MANAGER_ID;

/*7. Query to list down all the employees from the healthcare and finance department using 
union. Take data from employee record table.*/
select * from employee.emp_record_table
where DEPT='FINANCE'
union 
select * from employee.emp_record_table
where DEPT='HEALTHCARE';

/*8. Query to list down employee details such as emp_id,first_name,last_name,role,dept
and emp_rating grouped by dept. Also include the respective emp_rating and the max emp_rating for 
each department*/
#select DEPT,EMP_ID,FIRST_NAME,LAST_NAME,ROLE,EMP_RATING from employee.emp_record_table
#group by DEPT; #doesnt work??????

select DEPT,EMP_ID,FIRST_NAME,LAST_NAME,ROLE,EMP_RATING from employee.emp_record_table
order by DEPT;

select DEPT,max(emp_rating) from employee.emp_record_table
group by DEPT;

select EMP_ID, FIRST_NAME, LAST_NAME, ROLE, DEPT,EMP_RATING,
(select max(EMP_RATING) from employee.emp_record_table b where a.DEPT = b.DEPT) as maxRating
from employee.emp_record_table a 
order by a.DEPT;

/*9. Query to calculate min and max salary of employees in each role*/
select role, max(SALARY), min(SALARY) from employee.emp_record_table
group by role;

/*10. Query to assign rank to each employee based on their experience*/
select emp_id,first_name,last_name,role,exp,dense_rank() over (order by exp desc) as rank_
from employee.emp_record_table;

/*11. Query to create a view that displays employees in various countries whose salary 
is more than 6000*/
#created using side tab not query 
create view EMP_H_SAL as
SELECT FIRST_NAME,LAST_NAME,GENDER,ROLE,DEPT,EXP,COUNTRY,SALARY FROM employee.emp_record_table
WHERE SALARY > 6000;

select * from EMP_H_SAL;

/*12. Write a nested query to find employees with experience of more than 10 years*/
select EMP_ID,FIRST_NAME,LAST_NAME from employee.emp_record_table 
where exp >10; #this wouldnt require a nested query?

select EMP_ID,FIRST_NAME,LAST_NAME from employee.emp_record_table 
where EXP = ANY (select EXP from employee.emp_record_table where exp>10);

/*13. Query to create a stored procedure to retrieve the details of the employees whose experience
is more than three years*/
#temporary delimiter used to create procedure - created with side tab not query 
DELIMITER && 
create procedure threeyrs_exp()
Begin 
select * from employee.emp_record_table where EXP >3;
end &&
CALL threeyrs_exp();

/*14. Query using stored functions in the project table? to check whether the job profiles 
assigned to each employee in the data science team matches the organization's set standard*/
#couldn't find the answer 
DELIMITER $$
create function emp_role(exp int)
returns varchar(20)
deterministic 
begin
declare emp_role varchar(20);
if EXP <=2 then set emp_role='JUNIOR DATA SCIENTIST';
elseif (EXP>2 and EXP<=5) then set emp_role='ASSOCIATE DATA SCIENTIST';
elseif (EXP>5 and EXP<=10) then set emp_role='SENIOR DATA SCIENTIST';
elseif (EXP>10 and EXP<=12) then set emp_role='LEAD DATA SCIENTIST';
elseif (EXP>12 and EXP<=16) then set emp_role='MANAGER';
end if;
return (emp_role);
RETURN (emp_role);
end &&


/*15. Index to improve the cost and performance of the query to find the employee whose first_name
is 'Eric' in the employee table after checking the execution plan*/
Explain select * from employee.emp_record_table 
where FIRST_NAME= 'Eric';

create index index_id on employee.emp_record_table (FIRST_NAME(255));
explain select * from employee.emp_record_table where FIRST_NAME = 'Eric';

show indexes from employee.emp_record_table;

/*16. Query to calculate the bonus for all the employees, based on their ratings and salaries (5%
salary * employee rating)*/

select EMP_ID,FIRST_NAME,LAST_NAME,EMP_RATING,SALARY, 0.05*SALARY*EMP_RATING as Bonus 
from employee.emp_record_table;

/*17. Query to calculate the average salary distribution based on continent and country*/

select COUNTRY, STD(SALARY) from employee.emp_record_table
group by country;
select CONTINENT, STD(SALARY) from employee.emp_record_table
group by continent;



